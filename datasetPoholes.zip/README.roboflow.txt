
devpost - v1 post
==============================

This dataset was exported via roboflow.ai on August 3, 2021 at 2:22 PM GMT

It includes 300 images.
Post are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


